#ifndef __SOFTWARE_TIMER_
#define __SOFTWARE_TIMER_

extern int timer_flag;

void setTimer(int duration);
void timerRun();


#endif
