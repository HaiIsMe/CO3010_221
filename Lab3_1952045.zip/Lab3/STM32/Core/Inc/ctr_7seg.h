/*
 * ctr_7seg.h
 *
 *  Created on: Nov 12, 2022
 *      Author: Asus
 */

#ifndef INC_CTR_7SEG_H_
#define INC_CTR_7SEG_H_

#include "global.h"

void turnSeg0(int num);

void turnSeg1(int num);

void enableSeg(int num1, int num2);

#endif /* INC_CTR_7SEG_H_ */
