/*
 * fsm_manual.h
 *
 *  Created on: Nov 13, 2022
 *      Author: Asus
 */

#ifndef INC_FSM_MANUAL_H_
#define INC_FSM_MANUAL_H_

#include "global.h"

void fsm_manual_run();

#endif /* INC_FSM_MANUAL_H_ */
