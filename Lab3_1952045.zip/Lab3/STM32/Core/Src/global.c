#include "global.h"

int state = INIT;

int stateSeg = 0;

int durForRed;

int durForGreen;

int number1;

int number2;


